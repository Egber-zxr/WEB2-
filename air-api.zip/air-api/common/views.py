from django.shortcuts import render
import time
from django.shortcuts import HttpResponse  # 导入HttpResponse模块
import json
def upload(request):
    # 请求方法为POST时,进行处理;
    if request.method == "POST":
        # 获取上传的文件,如果没有文件,则默认为None;
        File = request.FILES.get("file", None)
        timestamp = time.time()        
        tuple_time = time.localtime(timestamp)
        newfile=time.strftime("%Y%m%d%H%M%S", tuple_time)
        filet=File.name
        index = filet.find(".")
        filetype=filet[index:len(filet)]
        if File is None:
            return HttpResponse("no files for upload!")
        else:
            # 打开特定的文件进行二进制的写操作;
            with open("./static/%s" % newfile+filetype, 'wb+') as f:
                # 分块写入文件;
                for chunk in File.chunks():
                    f.write(chunk)
            content = {
                    'success': True,
                    'message': '上传成功',
                    'data':"http://localhost:8082/static/%s" % newfile+filetype               
                }
            return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')
    else:
        content = {
                    'success': True,
                    'message': '上传失败'                
                }
        return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')