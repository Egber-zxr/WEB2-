import json
from django.shortcuts import render
from django.shortcuts import HttpResponse  # 导入HttpResponse模块
from datetime import datetime
from air.models import Air
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage, InvalidPage

def list(request):  # request是必须带的实例。类似class下方法必须带self一样  
    res=Air.objects.filter().all()
    resList=[]
    for p in res:
        college = {}
        college['id'] =p.id
        college['airCode'] =p.airCode
        college['airCna'] =p.airCna
        college['status'] =p.status
        college['reserve1'] =p.reserve1
        college['reserve2'] =p.reserve2
        college['reserve3'] =p.reserve3
        college['reserve4'] =p.reserve4
        college['reserve5'] =p.reserve5
        college['airC'] =p.airC
        college['airF'] =p.airF
        college['airFna'] =p.airFna
        college['airTotal'] =p.airTotal
        college['airY'] =p.airY
        college['airYna'] =p.airYna
        resList.append(college)   
    content = {
                'success': True,
                'message': '查询成功',
                'data':resList
            }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')
def info(request):  # request是必须带的实例。类似class下方法必须带self一样  
    query_dict = request.GET
    id = query_dict.get('id')  
    re=Air.objects.get(id=id)
    newre={}
    newre['id'] =re.id
    newre['airCode'] =re.airCode
    newre['airCna'] =re.airCna
    newre['status'] =re.status
    newre['reserve1'] =re.reserve1
    newre['reserve2'] =re.reserve2
    newre['reserve3'] =re.reserve3
    newre['reserve4'] =re.reserve4
    newre['reserve5'] =re.reserve5
    newre['airC'] =re.airC
    newre['airF'] =re.airF
    newre['airFna'] =re.airFna
    newre['airTotal'] =re.airTotal
    newre['airY'] =re.airY
    newre['airYna'] =re.airYna
    content = {
                'success': True,
                'message': '查询成功',
                'data':newre
            }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')
def info1(request):  # request是必须带的实例。类似class下方法必须带self一样  
    query_dict = request.GET
    airCode = query_dict.get('airCode')  
    re=Air.objects.get(airCode=airCode)
    newre={}
    newre['id'] =re.id
    newre['airCode'] =re.airCode
    newre['airCna'] =re.airCna
    newre['status'] =re.status
    newre['reserve1'] =re.reserve1
    newre['reserve2'] =re.reserve2
    newre['reserve3'] =re.reserve3
    newre['reserve4'] =re.reserve4
    newre['reserve5'] =re.reserve5
    newre['airC'] =re.airC
    newre['airF'] =re.airF
    newre['airFna'] =re.airFna
    newre['airTotal'] =re.airTotal
    newre['airY'] =re.airY
    newre['airYna'] =re.airYna
    content = {
                'success': True,
                'message': '查询成功',
                'data':newre
            }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')
def delete(request):  # request是必须带的实例。类似class下方法必须带self一样  
    query_dict = request.GET
    id = query_dict.get('id')  
    re=Air.objects.get(id=id).delete()   
    content = {
                'success': True,
                'message': '删除成功',             
            }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')

def save(request):
    jsonData = json.loads(request.body.decode())
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    air=Air()
    try:
        air.airCode=jsonData['airCode']
    except Exception:
        print("airCode is null")
    try:
        air.airCna=jsonData['airCna']
    except Exception:
        print("airCna is null")
    try:
        air.status=jsonData['status']
    except Exception:
        print("status is null")
    try:
        air.reserve1=jsonData['reserve1']
    except Exception:
        print("reserve1 is null")
    try:
        air.reserve2=jsonData['reserve2']
    except Exception:
        print("reserve2 is null")
    try:
        air.reserve3=jsonData['reserve3']
    except Exception:
        print("reserve3 is null")
    try:
        air.reserve4=jsonData['reserve4']
    except Exception:
        print("reserve4 is null")
    try:
        air.reserve5=jsonData['reserve5']
    except Exception:
        print("reserve5 is null")
    try:
        air.airC=jsonData['airC']
    except Exception:
        print("airC is null")
    try:
        air.airF=jsonData['airF']
    except Exception:
        print("airF is null")
    try:
        air.airFna=jsonData['airFna']
    except Exception:
        print("airFna is null")
    try:
        air.airTotal=jsonData['airTotal']
    except Exception:
        print("airTotal is null")
    try:
        air.airY=jsonData['airY']
    except Exception:
        print("airY is null")
    try:
        air.airYna=jsonData['airYna']
    except Exception:
        print("airYna is null")
    air.create_time=now	
    air.save()
    content = {
                    'success': True,
                    'message': '新增成功',
                    'data':jsonData
                }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')
def update (request):
    jsonData = json.loads(request.body.decode())
    re = Air.objects.get(id=jsonData['id'])
    try:
        re.airCode=jsonData['airCode']
    except Exception:
        print("airCode is null")
    try:
        re.airCna=jsonData['airCna']
    except Exception:
        print("airCna is null")
    try:
        re.status=jsonData['status']
    except Exception:
        print("status is null")
    try:
        re.reserve1=jsonData['reserve1']
    except Exception:
        print("reserve1 is null")
    try:
        re.reserve2=jsonData['reserve2']
    except Exception:
        print("reserve2 is null")
    try:
        re.reserve3=jsonData['reserve3']
    except Exception:
        print("reserve3 is null")
    try:
        re.reserve4=jsonData['reserve4']
    except Exception:
        print("reserve4 is null")
    try:
        re.reserve5=jsonData['reserve5']
    except Exception:
        print("reserve5 is null")
    try:
        re.airC=jsonData['airC']
    except Exception:
        print("airC is null")
    try:
        re.airF=jsonData['airF']
    except Exception:
        print("airF is null")
    try:
        re.airFna=jsonData['airFna']
    except Exception:
        print("airFna is null")
    try:
        re.airTotal=jsonData['airTotal']
    except Exception:
        print("airTotal is null")
    try:
        re.airY=jsonData['airY']
    except Exception:
        print("airY is null")
    try:
        re.airYna=jsonData['airYna']
    except Exception:
        print("airYna is null")
    re.save()
    content = {
                    'success': True,
                    'message': '修改成功',
                    'data':jsonData
                }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')
def page(request):  # request是必须带的实例。类似class下方法必须带self一样   
    data = json.loads(request.body.decode())
    pageNum = data['pageNum']
    pagesize = data['pageSize']
    search = data['search']
    res1=[]
    if search:
        res1=Air.objects.filter(name=search)
    else:
        res1=Air.objects.filter()
        #Pagination
    total = res1.count()
    p = Paginator(res1, pagesize) # Show 10 contacts per page.
    page=[]
    try:
        page = p.page(pageNum)
    except PageNotAnInteger:
        page = p.page(pageNum)
    except EmptyPage:
        page = p.page(pageNum)
    resList=[]
    for p in page:
        college = {} 
        college['id'] =p.id
        college['airCode'] =p.airCode
        college['airCna'] =p.airCna
        college['status'] =p.status
        college['reserve1'] =p.reserve1
        college['reserve2'] =p.reserve2
        college['reserve3'] =p.reserve3
        college['reserve4'] =p.reserve4
        college['reserve5'] =p.reserve5
        college['airC'] =p.airC
        college['airF'] =p.airF
        college['airFna'] =p.airFna
        college['airTotal'] =p.airTotal
        college['airY'] =p.airY
        college['airYna'] =p.airYna
        resList.append(college)        
    content = {
                    'success': True,
                    'message': '查询成功',
                    'data':resList,
                    'total':total
                }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')